print('CODE TO GET THE NECESSARY INFORMATION FOR BUILDING AND CONSTRUCTING \n'
      'WATER DISTRIBUTION SYSTEM THAT STORES WATER IN AN ELEVATED TANK. ')


# function to calculate the height of a column of water from a tower height and a tank wall height
# h is height of the water column
# t is the height of the tower
# w is the height of the walls of the tank that is on top of the tower
def water_column_height(t, w):
    h = t + ((3 * w) / 4)
    return h


# pressure in kilopascals
def pressure_gain_from_water_height(height):
    # density of water 998,2(kilogram/meter^3)
    p = 998.2
    # acceleration from earth,s gravity 9.80665 (meter / second^2)
    g = 9.80665
    # h height of a column of water column in meters
    h = water_column_height(height, 0)  # Pass height as t and 0 as w
    pressure = (p * g * h) / 1000
    return pressure


def pressure_lost_from_pipe(d, L, f, v):
    # d is the diameter of the pipe in meters
    # L is the length of the pipe in meters
    # f is the pipe's friction factor
    # v velocity of the water flowing through the pipe in meters/second(fluid_velocity)
    # p is the density of water  998.2 (kilogram / meter^3)
    p = 998.2  # Density of water in kg/m^3
    pressure_lost = (-f * (L * p * (v**2))) / (2000 * d)
    return pressure_lost
