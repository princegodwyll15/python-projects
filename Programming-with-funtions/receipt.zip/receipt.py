import csv
from datetime import datetime
   
def main():
    PRODUCT_INDEX = 0
    products = read_dictionary("products.csv", PRODUCT_INDEX)
    print("Products Dictionary:")
    print(products)
    print()
    
    request_dict = {}
    with open("request.csv", "rt") as request_file:
        reader = csv.reader(request_file)
        next(reader)
        for each_request in reader:
            if len(each_request) != 0:
                key = each_request[PRODUCT_INDEX]
                request_dict[key] = each_request[1:]
    
    print("Request Dictionary:")
    print(request_dict)
    print()
    
    for product_num, quantity in request_dict.items():
        if product_num in products:
            product_info = products[product_num]
            name_of_product = product_info[0]
            price_of_product = float(product_info[1])
            print(f"Product Name: {name_of_product}")
            print(f"Requested Quantity: {quantity[0]}")
            print(f"Product Price: ${price_of_product:.2f}")
            print()  # Empty line for better readability
        else:
            print(f"Product {product_num} not found in products dictionary")
            
    # the time of the computer's operating system.
    current_date_and_time = datetime.now()
    # day of the week and the current time.
    print(f"{current_date_and_time:%A %I:%M %p}")



def read_dictionary(filename, key_column_index):
    """Read the contents of a CSV file into a compound
    dictionary and return the dictionary.
    Parameters
    filename: the name of the CSV file to read.
    key_column_index: the index of the column
    to use as the keys in the dictionary.
    Return: a compound dictionary that contains
    the contents of the CSV file.
    """
    product_dict = {}
    with open(filename, "rt") as product_file:
        reader = csv.reader(product_file)
        next(reader)
        for each_product in reader:
            if len(each_product) != 0:
                #product is index[0] #name is inedexed [1] #price is indexed [2]
                key = each_product[key_column_index]
                #start printing the diction from index one sice the product is now our key
                product_dict[key] = each_product[1:]
    return product_dict
      

if __name__ == "__main__":
  main()
